// Kim Benedick B. Lauron
// DIT 1-1

import java.util.*;

public class modularcalc
{
    public static double add (double a, double b){
        return a + b;
    }
    public static double subtract (double a, double b){
        return a - b;
    }
    public static double multiply (double a, double b){
        return a * b;
    }
    public static double divide (double a, double b){
        if (b ==0){
            System.out.println("ERROR: Division by zero is not allowed!");
            return 0;
        }
        return a / b;
    }
    
    public static void main (String [] args)
    {
        Scanner scan = new Scanner (System.in);
        int choice;
        double a, b, result;
        
        do {
            System.out.println("WELCOME TO CALCULATOR MENU");
            System.out.println("//////////////////////////");
            System.out.println("1. Addition");
            System.out.println("2. Subtraction");
            System.out.println("3. Multiplication");
            System.out.println("4. Division");
            System.out.println("5. Exit calculator");
            System.out.println("//////////////////////////");
            System.out.println("Please enter your choice (1-5):");
            
            choice = scan.nextInt();
            
            if (choice >= 1 && choice <=4){
                
                System.out.println("Enter the first number:");
                a = scan.nextDouble();
                System.out.println("Enter the second number:");
                b = scan.nextDouble();
                
                switch (choice) {
                    case 1: 
                        result = (a + b);
                        System.out.println("Result: " + result);
                        break;
                    case 2: 
                        result = (a - b);
                        System.out.println("Result: " + result);
                        break;
                    case 3: 
                        result = (a * b);
                        System.out.println("Result: " + result);
                        break;
                    case 4: 
                        result = (a / b);
                        System.out.println("Result: " + result);
                        break;
                }
            } 
            else if (choice != 5){
                System.out.println("Invalid choice. Please try again.");
            }
        }
        while (choice != 5);
        System.out.println("Calculator closed. Thank you for using!");
        scan.close();
    }
}